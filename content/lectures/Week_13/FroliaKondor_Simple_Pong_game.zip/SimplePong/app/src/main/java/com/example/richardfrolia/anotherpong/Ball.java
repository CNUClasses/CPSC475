package com.example.richardfrolia.anotherpong;

import android.graphics.Bitmap;
import android.graphics.Point;

/**
 * Created by Richard Frolia on 4/10/2018.
 */

public class Ball {
    private Point location;
    private boolean directionRight = true;
    private boolean directionDown = true;
    private Bitmap myBitmap;
    private int scoreFor, scoreAgainst = 0;

    int minX = 5;
    int maxX = 1750;
    int minY = 5;
    int maxY = 850;

    public Ball(Point location, Bitmap bmp) {
        this.location = location;
        myBitmap = bmp;
    }

    public void switchLateralDirection(){
        directionRight = !directionRight;
    }

    public void move(){
        double newX = location.x;
        double newY = location.y;
        if (directionRight && directionDown){
            newX += 40;
            newY += 40;
        }
        else if (!directionRight && !directionDown){
            newX -= 40;
            newY -= 40;
        }
        else if (!directionRight && directionDown){
            newX -= 40;
            newY += 40;
        }
        else{
            newX += 40;
            newY -= 40;
        }

        if (directionRight && newX >= maxX){
            newX = 905;
            newY = 430;
            scoreAgainst++;
        }
        if (!directionRight && newX <= minX){
            directionRight = !directionRight;
            newX = 905;
            newY = 430;
            scoreFor++;
        }
        if (directionDown && newY >= maxY){
            directionDown = !directionDown;
        }
        if (!directionDown && newY <= minY){
            directionDown = !directionDown;
        }

        setLocation(new Point((int)newX, (int)newY));
    }

    public void setLocation(Point location){
        this.location.set(location.x, location.y);
    }
    public Point getLocation(){
        return location;
    }
    public int getScoreFor(){
        return scoreFor;
    }
    public int getScoreAgainst(){
        return scoreAgainst;
    }

}
