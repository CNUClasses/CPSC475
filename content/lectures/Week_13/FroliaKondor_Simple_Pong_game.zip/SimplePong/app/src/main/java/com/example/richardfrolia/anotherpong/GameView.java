package com.example.richardfrolia.anotherpong;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * Created by Richard Frolia on 4/10/2018.
 */

public class GameView extends SurfaceView {

    GameThread thread;
    SurfaceHolder holder;
    Ball myBall;
    Bitmap myBitmapBall;
    CPU myCPU;
    Player myPlayer;


    public GameView(Context context) {
        super(context);
        thread = new GameThread(this);
        myBall = new Ball(new Point(905, 430), myBitmapBall);
        myCPU = new CPU();
        myPlayer = new Player();



        holder = getHolder();
        holder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                thread.setRunning(true);
                thread.start();
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                thread.setRunning(false);
            }
        });
    }

    @Override
    public void draw(Canvas canvas){
        super.draw(canvas);

        canvas.drawColor(Color.WHITE);

        myBitmapBall = BitmapFactory.decodeResource(getResources(), R.drawable.pingpongorange);
        myBitmapBall = Bitmap.createScaledBitmap(myBitmapBall, 60, 60, true);
        myBall.move();
        myCPU.move();

        canvas.drawBitmap(myBitmapBall, myBall.getLocation().x, myBall.getLocation().y, null);
        Paint black = new Paint();
        black.setColor(Color.BLACK);
        canvas.drawRect(myCPU.left, myCPU.top, myCPU.right, myCPU.bottom, black);
        canvas.drawRect(myPlayer.left, myPlayer.top, myPlayer.right, myPlayer.bottom, black);


        if ((myBall.getLocation().y <= myCPU.bottom && myBall.getLocation().y >= myCPU.top && myBall.getLocation().x <= 40)||(myBall.getLocation().y <= myPlayer.bottom && myBall.getLocation().y >= myPlayer.top && myBall.getLocation().x >= 1700)){
            myBall.switchLateralDirection();
        }

        black.setStyle(Paint.Style.FILL_AND_STROKE);
        black.setTextSize(100);
        canvas.drawText(String.valueOf(myBall.getScoreAgainst()), 600, 200, black);
        canvas.drawText(String.valueOf(myBall.getScoreFor()), 1150, 200, black);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX() - 40;
        int y = (int) event.getY() - 40;

        myPlayer.setBottom(y + 125);

        myPlayer.setTop(y - 125);

        return true;
    }
}
