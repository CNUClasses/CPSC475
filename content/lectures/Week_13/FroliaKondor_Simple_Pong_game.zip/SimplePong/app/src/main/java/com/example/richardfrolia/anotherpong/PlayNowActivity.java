package com.example.richardfrolia.anotherpong;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Richard Frolia on 4/10/2018.
 */

public class PlayNowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new GameView(this));
    }}
