package com.example.richardfrolia.anotherpong;

/**
 * Created by Richard Frolia on 4/10/2018.
 */

public class CPU {
    int left = 10;
    int right = 40;
    int top = 325;
    int bottom = 575;
    int minY = 5;
    int maxY = 850;
    boolean goingDown = true;

    public void CPU(){}

    public void move(){
        if (goingDown){
            top -= 20;
            bottom -= 20;
            if (top <= minY){
                goingDown = !goingDown;
            }
        }
        if (!goingDown){
            top += 20;
            bottom += 20;
            if (bottom >= maxY){
                goingDown = !goingDown;
            }
        }
    }
}
