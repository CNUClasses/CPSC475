package com.example.richardfrolia.anotherpong;

/**
 * Created by Richard Frolia on 4/10/2018.
 */

public class Player {
    int left = 1735;
    int right = 1765;
    int top = 325;
    int bottom = 575;

    public void Player(){}

    public void setTop(int top){this.top = top;}
    public void setBottom(int bottom){this.bottom = bottom;}

}
