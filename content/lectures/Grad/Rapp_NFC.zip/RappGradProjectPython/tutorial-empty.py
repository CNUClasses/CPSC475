import smartcard

# acr122u read binary - [0xFF, 0xB0, 0x00, page, length] -> [data], sw1, sw2
# acr122u write binary - [0xFF, 0xD6, 0x00, page, length] + [data] -> sw1, sw2


def main():
    pass


if __name__ == "__main__":
    main()
