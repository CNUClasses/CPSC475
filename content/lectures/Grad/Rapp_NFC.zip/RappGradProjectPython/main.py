import os
from PIL import Image
import smartcard


# thanks chatgpt (i did not care to write this myself)
def print_columns(data_list, columns):
    """
    Prints elements of a list in a specified number of columns with even spacing.

    Args:
        data_list (list): The list of elements to be printed.
        columns (int): The number of columns before starting a new line.
    """
    # Determine the max width of any element in the list for even spacing
    max_width = max(len(hex(item)) for item in data_list)

    for i, item in enumerate(data_list):
        # Print each item with padding for even spacing
        print(f"{hex(item):<{max_width}}", end="  ")

        # Print a new line after the specified number of columns
        if (i + 1) % columns == 0:
            print()

    # Print a final newline in case the last row was incomplete
    if len(data_list) % columns != 0:
        print()


def get_menu_text():
    return "a = (get) all card data\n"\
           "d = delete user memory\n"\
           "g = get user memory\n" \
           "i = interpret record\n"\
           "m = menu help\n"\
           "o = open records\n"\
           "p = place record\n"\
           "r = read raw bytes\n"\
           "t = type of record help\n"\
           "w = write raw bytes\n"\
           "x = exit program"
            # "c = clear record\n"\


def get_record_types_text():
    return "0x00 = null/none\n"\
           "0x01 = String\n"\
           "0x02 = Image (png)\n"\
           "0x13 = Pokemon (gen 3 format)"


def prompt_confirmation():
    response = input("Confirm this action? Y = yes, N = no: ").lower()
    return response == 'y' or response == "yes"


def prompt_byte_payload():
    length = prompt_hex_input("Enter the number of bytes to write in hex format: ")

    payload = []

    for i in range(length):
        payload.append(prompt_hex_input("Enter a byte in hex format: "))

    return payload


def prompt_hex_input(prompt):
    while True:
        try:
            hex_input = input(prompt)

            if len(hex_input) == 2 and int(hex_input, 16) <= 0xFF:
                byte = int(hex_input, 16)
                return byte
            else:
                print("Invalid input. Please enter exactly two hexadecimal characters (00 to FF).")

        except ValueError:
            print("Invalid format. Make sure to enter a valid hexadecimal value (eg. '0A').")


def get_entire_card(connection):
    return read_raw_bytes(connection, 0x00, 540)


def get_user_memory(connection):
    return read_raw_bytes(connection, 0x04, 504)


def delete_user_memory(connection):
    write_raw_bytes(connection, 0x04, 504 * [0x00], "Cleared user memory.")


# acr122u read binary - [0xFF, 0xB0, 0x00, page, length] -> data, sw1, sw2
def read_raw_bytes(connection, page, length):
    num_pages = length // 0x04 + 1
    num_extra = length % 0x04
    data = []

    for i in range(num_pages):
        apdu = [0xFF, 0xB0, 0x00, page + i, 0x04]
        response, sw1, sw2 = connection.transmit(apdu)
        data += response

    for i in range(0x04 - num_extra):
        data.pop()

    return data


# acr122u write binary - [0xFF, 0xD6, 0x00, page, length, data] -> sw1, sw2
def write_raw_bytes(connection, page, data, success_message):
    length = len(data)

    num_pages = length // 0x04
    num_extra = length % 0x04

    if num_extra > 0:
        for i in range(0x04 - num_extra):
            data += [0x00]
        num_pages += 1

    if page + num_pages > 0x82:
        print("Data will surpass user memory limit.")
        return

    for i in range(num_pages):
        data_chunk = data[i * 0x04: i * 0x04 + 0x04]
        apdu = [0xFF, 0xD6, 0x00, page + i, 0x04] + data_chunk
        response, sw1, sw2 = connection.transmit(apdu)

    print(success_message)


def open_custom_records(connection):
    user_memory = get_user_memory(connection)
    records = []

    i = 0
    while i < len(user_memory):
        if user_memory[i] == 0:
            i += 1
            continue

        record_offset = i
        record_type = user_memory[i]
        i += 1
        record_length = user_memory[i]
        i += 1
        record_data = []

        for j in range(record_length):
            record_data.append(user_memory[i + j])

        i += record_length

        records.append((record_offset, record_type, record_length, record_data))

    return records


def interpret_record(record):
    record_offset, record_type, record_length, record_data = record

    print(f"{hex(record_type)} type at offset {hex(record_offset)}:")

    match record_type:
        case 0x01:
            print(convert_int_list_to_string(record_data))

        case 0x02:
            write_data_to_file(record_data, "image-nfc-output.png")
            view_image_with_pillow("image-nfc-output.png")

        case 0x13:
            write_data_to_file(record_data, "pkmn-gen3-nfc-output.pk3")
            print("Pokemon (gen 3) found. Wrote information to pkmn-gen3-nfc-output.pk3 for external viewing.")

        case _:
            print("Other/unimplemented record type.")


# chatgpt code
def view_image_with_pillow(file_name):
    """
    Opens and displays an image using the Pillow library.
    :param file_name: The path to the image file.
    """
    try:
        img = Image.open(os.path.join("files", file_name))
        img.show()

    except FileNotFoundError:
        print("The specified file was not found.")

    except Exception as e:
        print(f"An error occurred: {e}")


def get_data_from_file():
    while True:
        file_path = input("Enter the filename: ").strip()
        file_path = os.path.join("files", file_path)

        if os.path.isfile(file_path):
            try:
                with open(file_path, 'rb') as file:
                    return file.read()
            except Exception as e:
                print(f"Error reading file: {e}")
                continue
        else:
            print("Invalid filename or file does not exist. Please try again.")


def write_data_to_file(record_data, filename):
    with open(os.path.join("files", filename), "wb") as file:
        file.write(bytearray(record_data))


def convert_int_list_to_string(int_list):
    return "".join(chr(i) for i in int_list)


def convert_string_to_int_list(string):
    chars = list(string)
    return [ord(char) for char in chars]


def convert_byte_data_to_int_list(byte_data):
    return list(byte_data)


def main():
    readers = smartcard.System.readers()

    if len(readers) == 0:
        print("No readers detected. Ensure they're connected/compatible.")
        return

    elif len(readers) == 1:
        reader = readers[0]
        print(f"1 reader detected. Using the {reader}.")

    else:
        reader = readers[0]
        print(f"{len(readers)} readers detected. Using the {reader}.")

    try:
        connection = reader.createConnection()
        connection.connect()

    except smartcard.Exceptions.NoCardException:
        print("No card found on the reader.")
        return

    except Exception:
        print("Some other exception occurred.")
        return

    print(get_menu_text())

    while True:
        option = input("Select a menu option: ").lower()

        match option:
            case 'a':
                print_columns(get_entire_card(connection), 4)

            # case 'c':
            #     # TODO
            #     print("UNIMPLEMENTED")

            case 'd':
                print("Preparing to delete user memory.")
                if prompt_confirmation():
                    delete_user_memory(connection)

            case 'g':
                print_columns(get_user_memory(connection), 4)

            case 'i':
                records = open_custom_records(connection)

                if len(records) == 0:
                    print("No records to interpret.")
                    continue

                # not safe with bad inputs but idc
                index = int(input(f"{len(records)} record(s) found, give an index to check: "))

                interpret_record(records[index])

            case 'm':
                print(get_menu_text())

            case 'o':
                records = open_custom_records(connection)

                if len(records) == 0:
                    print("No records found.")
                    continue

                print(f"Found {len(records)} record(s). Format: type/offset/length")
                for record in records:
                    print(f"{hex(record[1])}/{hex(record[0])}/{hex(record[2])}")

            case 'p':
                records = open_custom_records(connection)

                page = 0x04

                if len(records) > 0:
                    last_record = records[-1]
                    byte_offset = last_record[0] + last_record[2] + 0x02
                    if byte_offset % 0x04 > 0:
                        page += 1
                    page += byte_offset // 0x04

                record_type = prompt_hex_input("Enter a record type in hex format: ")

                match record_type:
                    case 0x01:
                        message = input("Enter a message to leave on the card: ")
                        if prompt_confirmation():
                            write_raw_bytes(connection, page,
                                            [record_type, len(message)] + convert_string_to_int_list(message),
                                            f"Wrote {message} to memory.")

                    case 0x02:
                        data = convert_byte_data_to_int_list(get_data_from_file())
                        if prompt_confirmation():
                            write_raw_bytes(connection, page,
                                            [record_type, len(data)] + data,
                                            "Wrote png image to memory.")

                    case 0x13:
                        data = convert_byte_data_to_int_list(get_data_from_file())
                        if prompt_confirmation():
                            write_raw_bytes(connection, page,
                                            [record_type, len(data)] + data,
                                            "Wrote Pokemon (gen 3) to memory.")

                    case _:
                        print("Other/unimplemented record type.")

            case 'r':
                page = prompt_hex_input("Enter a page number in hex format: ")
                length = prompt_hex_input("Enter the number of bytes to read in hex format: ")
                raw_bytes = read_raw_bytes(connection, page, length)
                print_columns(raw_bytes, 4)

            case 't':
                print(get_record_types_text())

            case 'w':
                page = prompt_hex_input("Enter a page number in hex format: ")
                payload = prompt_byte_payload()
                if prompt_confirmation():
                    write_raw_bytes(connection, page, payload, "Wrote data to memory.")

            case 'x':
                return

            case _:
                print("Other/invalid option selected")


if __name__ == '__main__':
    main()
