import smartcard

# acr122u read binary - [0xFF, 0xB0, 0x00, page, length] -> [data], sw1, sw2
# acr122u write binary - [0xFF, 0xD6, 0x00, page, length] + [data] -> sw1, sw2


def main():
    # get the reader and make connection with card
    reader = smartcard.System.readers()[0]
    connection = reader.createConnection()
    connection.connect()

    # read 0x04 bytes at page 0x04
    page = 0x04
    length = 0x04
    apdu = [0xFF, 0xB0, 0x00, page, length]
    response, sw1, sw2 = connection.transmit(apdu)
    print(response, hex(sw1), hex(sw2))

    # write 0x04 bytes from data to page 0x04
    page = 0x04
    length = 0x04
    apdu = [0xFF, 0xD6, 0x00, page, length]
    data = [0xAA, 0xBB, 0xCC, 0xDD]
    response, sw1, sw2 = connection.transmit(apdu + data)
    print(response, hex(sw1), hex(sw2))


if __name__ == "__main__":
    main()
