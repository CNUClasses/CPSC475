package com.example.solus.paws;

import android.content.res.Resources;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {

	// Global variables
	private View myView;
	private ImageView img;
	private int counter = 1;
	private boolean[] favorite = {false, false, false};
	private static final int RESET = 0;
	private static final int THRESHOLD_OF_FAVORITE = 2;
	private static final int DUMB_INDEX_ERROR_NUM = 3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Button, CheckBox, and View objects
		Button button = (Button) findViewById(R.id.button);
		CheckBox box = (CheckBox) findViewById(R.id.checkbox);
		myView = findViewById(R.id.imageView2);

		//ImageView object to hold pictures from drawable folder
		img = (ImageView) findViewById(R.id.imageView);

		//ID for the first picture to be displayed and set it on on creation of app
		int ID = getResources().getIdentifier("pet0", "drawable", getPackageName());
		img.setImageResource(ID);

		// Register the onClick listener with the implementation above
		button.setOnClickListener(buttonListener);
		box.setOnClickListener(boxListener);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		//noinspection SimplifiableIfStatement
		if (id == R.id.action_settings) {
			return true;
		}

		return super.onOptionsItemSelected(item);
	}

	// Listener for next button
	private View.OnClickListener buttonListener = new View.OnClickListener() {
		//Button to change pictures
		public void onClick(View v) {

			// Setting resources to get pet image
			String petImg = "pet" + Integer.toString(counter);
			int ID = getResources().getIdentifier(petImg, "drawable", getPackageName());
			img.setImageResource(ID);

			// Checks if counter needs to be reset to 0, else increase counter
			if (counter == THRESHOLD_OF_FAVORITE) {
				counter = RESET;
			} else {
				counter++;
			}

			// If we are on the favorite picture show hearts, else don't show hearts
			if (favorite[counter]) {
				setCheckTrue();
				myView.setBackground(getResources().getDrawable(R.drawable.hearts));
			} else {
				setCheckFalse();
				myView.setBackgroundColor(Color.TRANSPARENT);
			}
		}
	};

	// Listener for Checkbox
	private View.OnClickListener boxListener = new View.OnClickListener() {

		// On Click make a favorite
		public void onClick(View v) {

			// If counter becomes to big reset it to 0 to avoid crash
			if( counter == DUMB_INDEX_ERROR_NUM ){
				counter = RESET;
			}

			// Is the view now checked?
			boolean checked = ((CheckBox) v).isChecked();

			// If checkbox is checked set hearts as background and update favorites[],
			// else reset favorite[] and make background transparent
			if (checked) {
				for(int i = 0; i < favorite.length; i++){
					favorite[i] = false;
					myView.setBackgroundColor(Color.TRANSPARENT);
				}
				favorite[counter] = true;
				((CheckBox) v).setChecked(true);
				myView.setBackground(getResources().getDrawable(R.drawable.hearts));
			} else {
				for(int i = 0; i < favorite.length; i++){
					favorite[i] = false;
				}
				((CheckBox) v).setChecked(false);
				myView.setBackgroundColor(Color.TRANSPARENT);
			}
		}
	};

	// Wrapper to check the checkbox's state when true
	public void setCheckTrue(){
		CheckBox box = (CheckBox) findViewById(R.id.checkbox);
		box.setChecked(true);
	}

	// Wrapper to check the checkbox's state when false
	public void setCheckFalse(){
		CheckBox box = (CheckBox) findViewById(R.id.checkbox);
		box.setChecked(false);
	}

}